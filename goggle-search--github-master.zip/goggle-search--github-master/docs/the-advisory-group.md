# The Advisory Group

| **Important note** |
|:--|
| This group stopped working at the end of 2017 |

The group of volunteers we called Advisory Group have been working together for guidance and advise during the Transition period. 

This group is composed by Bilal Randeree (CC Qatar), Delia Browne (AU), Felix Nartey (Ghana), Mariana Valente (BR), Meredith Jacobs (US), Nic Suzor (AU), Paul Keller (NL), Scann (AR), Tomoaki Watanabe (JP). 

The Advisory Group meets every Tuesday at 9AM Chile (9PM Tokio, 2PM CET, 7AM CDT). All of the work of the Advisory Group is public. 

| Advisory Group meetings |  |
|:--|:--|
| **Last meeting** | Sept 26th. 2017 |
| **Next meeting** | --- |
| Meeting notes | [Meeting notes log](/docs/advisory_group_meeting_notes.md) |
