## Transition Timeline

| **Important note** |
|:--|
| This document is no longer updated as far the Global Network Council started working on November 2018 |

> (from now until CC Summit and first Global Network Council Meeting)

| [The Timeline for the Transition](https://creativecommons.org/2017/12/08/network-strategy-transition-towards-new-model/) |  |
|:--|:--|
| Opening of new memberships for Members and institutions  | January 15th, 2018 |
| First Chapter meetings _(every member have the right of being part of the chapter in the country where they live)_ | March, 2018 |
| Chapters select their Global Network Council representative | at first Chapter meeting |
| First Global Network Council meeting | May/June, 2018 |