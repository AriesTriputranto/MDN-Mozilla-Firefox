# The Interim Membership Council

| **Important note** |
|:--|
| This group stopped working at the end of March, 2019 |

This group is made up of longstanding volunteer and community members who were part of the Network Strategy and the Advisory Group. As members are approved, they will also be able to vouch for new members who apply. This way, we can all contribute to growing our community.

This group is composed by Carolina Botero (Colombia), Claudia Cristiani (El Salvador), Delia Browne (Australia), Kelsey Wiens (Canada), Muid Latif (Malaysia), Nic Suzor (Australia), Evelin Heidel (Argentina), Soohyun Pae (South Korea), Alek Tarkowski (Poland), Bilal Randeree (Qatar), Felix Nartey (Ghana), Mariana Valente (Brazil), Meredith Jacob (US), Tomoaki Watanabe (Japan), Paul Keller (Netherlands, CC Board), Claudio Ruiz (Chile, HQ), Ryan Merkley (Canada, HQ), Renata Avila (Guatemala, Board), Jay Yoon (South Korea, Board), Diane Peters (US, HQ).

The criteria for vouching and the criteria for approve memberships is open to everyone. You can learn about [the criteria to be used to vouch members here](Guide_for_vouching_applicants.md), and about the [criteria to be used to approve applications here](Guide_for_approve_new_members.md). 

| **Important note** |
|:--|
| This group will work until the first Membership Council will be stated by the Global Network Council in January, 2019 |